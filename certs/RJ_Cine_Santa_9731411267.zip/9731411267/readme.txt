This package contains the SM/PR identity certificate chain of a Barco ICMP module.
The certificates are distributed as follows:
	- as a single PEM file (friendly for most open source libraries)
	- as individual PEM files
	- certificates are DER encoded
	- ASCII armoured PEM files (base64 encoded)

For questions please contact Barco Support at https://www.barco.com/en/Support or at http://www.barco.com/esupport 
	
File list:

- Barco-ICMP.XXXXXXXXXX_chain.pem:	full certificate chain for the Barco ICMP module with serial number XXXXXXXXXX.
									The leaf certificate is the SM/PR identity certificate.
									Each certificate is DER encoded.

- Barco-ICMP.XXXXXXXXXX_cert.pem: 	leaf certificate for the Barco ICMP module with serial number XXXXXXXXXX.
									The certificate is the SM/PR identity certificate.
									The certificate is DER encoded.

- Barco-ICMP-ROOT_cert.pem: 		Barco CA Root certificate (self-signed).
									PKI Root of Trust for the Barco ICMP project.
								  
- Barco-ICMP-CA.XX._cert.pem: 		Barco CA signing certificates (non self-signed).
									Barco-ICMP-CA.01 is signed by Barco-ICMP-ROOT.
									Barco-ICMP-CA.02 is signed by Barco-ICMP-CA.01.
									...
									Barco-ICMP.XXXXXXXXXX_cert is signed by Barco-ICMP-CA.NN.

- readme.txt: 				this document.